<?php

namespace Ari\PageCacheDebug\Console\Command;

use Magento\Framework\App\Area;
use Magento\Framework\App\AreaList;
use Magento\Framework\App\State;
use Magento\Framework\Component\ComponentRegistrar;
use Magento\Framework\Module\Manager;
use Magento\Framework\Module\ModuleList\Loader;
use Magento\Framework\Module\PackageInfoFactory;
use Magento\Framework\ObjectManager\ObjectManager;
use Magento\Framework\View\DesignInterface;
use Magento\Framework\View\Layout\BuilderFactory;
use Magento\Framework\View\Result\LayoutFactory;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class IsLayoutCacheableCommand extends Command
{
    const STATUS_CACHEABLE = 0;
    const STATUS_NOT_CACHEABLE = 1;
    const STATUS_ERROR = -1;

    private $state;
    private $layoutFactory;
    private $builderFactory;
    private $areaList;
    private $design;

    public function __construct(
        State $state,
        LayoutFactory $layoutFactory,
        BuilderFactory $builderFactory,
        AreaList $areaList,
        DesignInterface $design
    ) {
        parent::__construct();
        $this->layoutFactory = $layoutFactory;
        $this->state = $state;
        $this->builderFactory = $builderFactory;
        $this->areaList = $areaList;
        $this->design = $design;
    }

    protected function configure()
    {
        $this->setName('ari:pagecachedebug:islayoutcacheable')
            ->addArgument('layout', InputArgument::REQUIRED, 'The layout name')
            ->addArgument('theme', InputArgument::REQUIRED, 'The theme name');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->state->setAreaCode(Area::AREA_FRONTEND);
        $this->areaList->getArea(Area::AREA_FRONTEND)->load();
        $this->design->setDesignTheme($input->getArgument('theme'), Area::AREA_FRONTEND);

        try {
            $pageLayout = $this->layoutFactory->create()
                ->addHandle($input->getArgument('layout'));

            $pageLayout->getLayout()->setBuilder($this->builderFactory->create(
                BuilderFactory::TYPE_PAGE,
                []
            ));
            return $pageLayout->getLayout()->isCacheable() ? static::STATUS_CACHEABLE : static::STATUS_NOT_CACHEABLE;
        } catch (\Exception|\Error $e) {
            // it will fail for some layouts, these that expect, for instance, to have
            // a product in there core registry so that their loadLayout() runs
            $output->writeln(sprintf("<error>%s: %s</error>", $input->getArgument('layout'), $e->getMessage()));
            return static::STATUS_ERROR;
        }
    }
}
