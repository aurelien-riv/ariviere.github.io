<?php

namespace Ari\PageCacheDebug\Console\Command;

use Magento\Framework\App\Area;
use Magento\Framework\App\AreaList;
use Magento\Framework\App\State;
use Magento\Framework\Component\ComponentRegistrar;
use Magento\Framework\Module\Manager;
use Magento\Framework\Module\ModuleList\Loader;
use Magento\Framework\Module\PackageInfoFactory;
use Magento\Framework\ObjectManager\ObjectManager;
use Magento\Framework\View\Layout\BuilderFactory;
use Magento\Framework\View\Result\LayoutFactory;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Helper\Table;
use Symfony\Component\Console\Helper\TableStyle;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class Dump extends Command
{
    private $moduleManager;
    private $fullModuleList;
    private $componentRegistrar;
    private $themeList;

    public function __construct(
        Loader $loader,
        Manager $moduleManager,
        ComponentRegistrar $componentRegistrar,
        \Magento\Framework\View\Design\Theme\ListInterface $themeList
    ) {
        parent::__construct();
        $this->fullModuleList = $loader->load();
        $this->moduleManager = $moduleManager;
        $this->componentRegistrar = $componentRegistrar;
        $this->themeList = $themeList;
    }

    protected function configure()
    {
        $this->setName('ari:pagecachedebug:dump')
            ->addArgument('themes', InputArgument::OPTIONAL, 'A coma separated list of theme codes');
    }

    private function getThemeCodes(InputInterface $input)
    {
        if ($input->getArgument('themes')) {
            return explode(',', $input->getArgument('themes'));
        }

        $themes = [];
        /** @var \Magento\Theme\Model\Theme $theme */
        foreach ($this->themeList as $theme) {
            if ($theme->getArea() === Area::AREA_FRONTEND) {
                $themes[] = $theme->getCode();
            }
        }
        return $themes;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $themes = $this->getThemeCodes($input);

        $tableStyle = new TableStyle();
        $tableStyle->setPadType(STR_PAD_BOTH);

        $table = new Table($output->section());
        $table->setStyle($tableStyle);
        $table->setHeaders(array_merge(['Layout'], $themes));
        $table->render();

        foreach ($this->getUniqueLayouts() as $layoutHandleName) {
            $row = [$layoutHandleName];
            foreach ($themes as $theme) {
                // we don't run that on the same process because of singletons.
                exec(sprintf(
                    "%s %s ari:pagecachedebug:islayoutcacheable %s %s",
                    PHP_BINARY,
                    $_SERVER['argv'][0],
                    $layoutHandleName,
                    $theme
                ), $cmdout, $status);
                switch ($status) {
                    case IsLayoutCacheableCommand::STATUS_CACHEABLE:
                        $row[] = '✔';
                        break;
                    case IsLayoutCacheableCommand::STATUS_NOT_CACHEABLE:
                        $row[] = '☓';
                        break;
                    case IsLayoutCacheableCommand::STATUS_ERROR:
                        $row[] = 'E';
                        break;
                }
            }
            $table->appendRow($row);
        }
    }

    private function getUniqueLayouts() : array
    {
        return array_unique(iterator_to_array($this->getLayouts()));
    }

    private function getLayouts() : \Generator
    {
        foreach ($this->fullModuleList as $moduleName => $moduleConfig) {
            if ($this->moduleManager->isEnabled($moduleName)) {
                $path = $this->componentRegistrar->getPath(ComponentRegistrar::MODULE, $moduleName);
                $directoryIterator = new \RecursiveDirectoryIterator($path);
                $directoryIterator = new \RecursiveIteratorIterator($directoryIterator);
                $directoryIterator = new \RegexIterator($directoryIterator, '/\/frontend\/layout/', \RecursiveRegexIterator::MATCH);

                /** @var \SplFileInfo $directory */
                foreach ($directoryIterator as $directory) {
                    $fileIterator = new \RecursiveDirectoryIterator($directory->getPath());
                    $fileIterator = new \RecursiveIteratorIterator($fileIterator);
                    $fileIterator = new \RegexIterator($fileIterator, '/^[^_]+_[^_]+_[^_]+\.xml$/', \RecursiveRegexIterator::MATCH);

                    /** @var \SplFileInfo $layout */
                    foreach ($fileIterator as $layout) {
                        yield preg_replace('/\.xml$/', '', $layout->getFilename());
                    }
                }
            }
        }
    }
}
